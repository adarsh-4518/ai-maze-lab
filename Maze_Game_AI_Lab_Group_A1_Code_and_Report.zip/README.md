# Maze Game Using Python — AI Lab

A playable desktop maze game built with **Python Tkinter**. It opens in a separate window on your laptop.

## How to run

1. Install Python 3 on Windows.
2. Extract the ZIP and open the project folder.
3. Run `python maze_game.py` in Command Prompt, or open `maze_game.py` in IDLE and press F5.

No extra Python packages are needed on a typical Windows Python installation.

## Controls

- **Arrow keys:** Move the blue player through the maze.
- **New Maze:** Generate another random maze.
- **BFS Solution:** Highlight a shortest path to the green exit.
- **DFS Solution:** Highlight a path found by depth-first search.

## Project details

- College: Lachoo Memorial College of Science and Technology
- Course: Bachelor of Computer Applications, Semester V
- Subject: AI Lab
- Group: A1
- Faculty Guide: Ms Sakshi Nankani
- Adarsh Chhangani — 243501008
- Gokul Singh Bhati — 243501058

## Files

- `maze_game.py` — complete runnable game
- `Maze_Game_AI_Lab_Report_Group_A1.pdf` — project report
- `README.md` — project instructions
