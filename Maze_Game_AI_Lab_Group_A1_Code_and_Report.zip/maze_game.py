"""Maze Game — AI Lab Group A1. Run: python maze_game.py"""
import tkinter as tk
from collections import deque
import random

ROWS, COLS, CELL = 15, 21, 28

class MazeGame:
    def __init__(self, root):
        self.root = root
        root.title('Maze Game | AI Lab - Group A1')
        self.canvas = tk.Canvas(root, width=COLS*CELL, height=ROWS*CELL)
        self.canvas.pack(padx=12, pady=10)
        controls = tk.Frame(root)
        controls.pack()
        tk.Button(controls, text='New Maze', command=self.new_maze).pack(side='left', padx=5)
        tk.Button(controls, text='BFS Solution', command=lambda: self.solve('BFS')).pack(side='left', padx=5)
        tk.Button(controls, text='DFS Solution', command=lambda: self.solve('DFS')).pack(side='left', padx=5)
        self.status = tk.Label(root, text='Use arrow keys to reach the green exit.')
        self.status.pack(pady=8)
        root.bind('<KeyPress>', self.move)
        self.new_maze()

    def new_maze(self):
        self.grid = [[1 for _ in range(COLS)] for _ in range(ROWS)]
        self.grid[1][1] = 0
        stack = [(1, 1)]
        while stack:
            r, c = stack[-1]
            options = []
            for dr, dc in [(-2, 0), (2, 0), (0, -2), (0, 2)]:
                nr, nc = r + dr, c + dc
                if 1 <= nr < ROWS-1 and 1 <= nc < COLS-1 and self.grid[nr][nc]:
                    options.append((nr, nc, dr, dc))
            if options:
                nr, nc, dr, dc = random.choice(options)
                self.grid[r + dr//2][c + dc//2] = 0
                self.grid[nr][nc] = 0
                stack.append((nr, nc))
            else:
                stack.pop()
        self.player = (1, 1)
        self.goal = (ROWS-2, COLS-2)
        self.path = []
        self.status.config(text='Use arrow keys to reach the green exit.')
        self.draw()
        self.canvas.focus_set()

    def neighbors(self, position):
        r, c = position
        for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nr, nc = r + dr, c + dc
            if 0 <= nr < ROWS and 0 <= nc < COLS and self.grid[nr][nc] == 0:
                yield nr, nc

    def solve(self, algorithm):
        frontier = deque([self.player]) if algorithm == 'BFS' else [self.player]
        parent = {self.player: None}
        while frontier:
            current = frontier.popleft() if algorithm == 'BFS' else frontier.pop()
            if current == self.goal:
                break
            for nxt in self.neighbors(current):
                if nxt not in parent:
                    parent[nxt] = current
                    frontier.append(nxt)
        self.path = []
        if self.goal in parent:
            current = self.goal
            while current is not None:
                self.path.append(current)
                current = parent[current]
            self.path.reverse()
            self.status.config(text=f'{algorithm} path: {len(self.path)-1} steps')
        self.draw()

    def move(self, event):
        offsets = {'Up': (-1, 0), 'Down': (1, 0), 'Left': (0, -1), 'Right': (0, 1)}
        if event.keysym not in offsets:
            return
        dr, dc = offsets[event.keysym]
        r, c = self.player
        next_position = (r + dr, c + dc)
        if next_position in self.neighbors(self.player):
            self.player = next_position
            self.path = []
            self.draw()
            if self.player == self.goal:
                self.status.config(text='You won! Click New Maze to play again.')

    def draw(self):
        self.canvas.delete('all')
        highlighted = set(self.path)
        for r in range(ROWS):
            for c in range(COLS):
                pos = (r, c)
                color = '#26364a' if self.grid[r][c] else '#f3f6fa'
                if pos in highlighted:
                    color = '#ffe4a3'
                if pos == self.goal:
                    color = '#43a047'
                if pos == self.player:
                    color = '#1976d2'
                x, y = c*CELL, r*CELL
                self.canvas.create_rectangle(x, y, x+CELL, y+CELL,
                                             fill=color, outline='#d6dce3')

if __name__ == '__main__':
    root = tk.Tk()
    MazeGame(root)
    root.mainloop()
